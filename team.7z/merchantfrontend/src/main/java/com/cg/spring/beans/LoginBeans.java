package com.cg.spring.beans;

public class LoginBeans {

	private String username;
	private String password;

	private String newPassword;

	private String confirmPassword;
	private String role = "customer";

	public LoginBeans(String username, String password, String newPassword, String confirmPassword, String role) {
		super();
		this.username = username;
		this.password = password;
		this.newPassword = newPassword;
		this.confirmPassword = confirmPassword;
		this.role = role;
	}

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}

	public LoginBeans() {
		// TODO Auto-generated constructor stub
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getNewPassword() {
		return newPassword;
	}

	public void setNewPassword(String newPassword) {
		this.newPassword = newPassword;
	}

	public String getConfirmPassword() {
		return confirmPassword;
	}

	public void setConfirmPassword(String confirmPassword) {
		this.confirmPassword = confirmPassword;
	}

}
