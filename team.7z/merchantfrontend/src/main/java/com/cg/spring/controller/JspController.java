package com.cg.spring.controller;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.web.authentication.logout.SecurityContextLogoutHandler;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.servlet.ModelAndView;

import com.cg.spring.beans.Inventory;
import com.cg.spring.beans.MerchantOrdeers;

@Controller
public class JspController {
	@RequestMapping("/home")
	public ModelAndView inventory() {
		RestTemplate st=new RestTemplate();
		List<Inventory> ivt= st.getForObject("http://localhost:8686/Minventory",ArrayList.class );
		return  new ModelAndView("MerchantInventory","inventory" ,ivt);
	}
	@RequestMapping("/addproduct")
	public String addproduct() {
		return "addproduct";
	}
	@RequestMapping("/delete")
	public String deleteproduct() {
		return "deleteproduct";
		
	}
	@RequestMapping("/")
	public String login() {
		return "login";
	}

	@RequestMapping("/l")
	public String l() {
		return "login";
	}

	@RequestMapping("/reset")
	public String reset() {
		return "resetPwd";
	}

	@RequestMapping("/index")
	public String home() {
		return "index";
	}

	@RequestMapping(value = "/login", method = RequestMethod.GET)
	public String loginPage() {
		return "login";
	}

	@RequestMapping(value="/logout", method = RequestMethod.GET)
	public String logoutPage (HttpServletRequest request, HttpServletResponse response) {
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		if (auth != null){    
			new SecurityContextLogoutHandler().logout(request, response, auth);
		}
		return "redirect:/login?logout";//You can redirect wherever you want, but generally it's a good idea to show login screen again.
	}

	
}
