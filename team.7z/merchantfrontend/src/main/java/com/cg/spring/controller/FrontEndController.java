package com.cg.spring.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.servlet.ModelAndView;

import com.cg.spring.beans.Admin;
import com.cg.spring.beans.Customer;
import com.cg.spring.beans.Inventory;
import com.cg.spring.beans.MerchantInfo;
import com.cg.spring.beans.MerchantOrdeers;

@RestController
public class FrontEndController {
	private static final String String = null;

	@RequestMapping("/Mprofile")
	public ModelAndView show1()
	{
		
		RestTemplate rt=new RestTemplate();
		MerchantInfo merchant=rt.getForObject("http://localhost:8686/Mprofile",MerchantInfo.class );
		return new ModelAndView("Mprofile","merchant" , merchant);
	}
	@RequestMapping("/orders")
	public ModelAndView display() {
		RestTemplate st=new RestTemplate();
		List<MerchantOrdeers> ord= st.getForObject("http://localhost:8686/orders",ArrayList.class );
		return  new ModelAndView("orders","od" ,ord);
	}
	@RequestMapping("/add")
	public String addproduct(@RequestParam String name,@RequestParam Integer id,@RequestParam String price,@RequestParam String des,@RequestParam String type,@RequestParam String email) {
		RestTemplate st=new RestTemplate();
		System.out.println(name+id);
		String res=st.getForObject("http://localhost:8686/addproduct?name="+name+"&id="+id+"&price="+price+"&des="+des+"&type="+type+"&email="+email,String.class);
	//	String result= st.getForObject("http://localhost:8686/addproduct/"+id+"/"+name+"/"+price+"/"+des+"/"+type+"/"+email+"/",String.class );
		return res;

	}
	@RequestMapping(value="/deleteproducts")
	public String deleteproduct(@RequestParam int id) {
		RestTemplate st=new RestTemplate();
		String res=st.getForObject("http://localhost:8686/deleteproducts?id="+id,String.class);
		return res;
		
	}
	
	@RequestMapping("/log")
	public ModelAndView logOn(String username, String password) {

		RestTemplate rt4 = new RestTemplate();
		String log = rt4.getForObject("http://localhost:8686/log?username=" + username + "&password=" + password,
				String.class);
		 if (log.equals("admin")) {
			return new ModelAndView("index", "user", log);
		} else if (log.equals("merchant")) {
			RestTemplate st=new RestTemplate();
			List<Inventory> ivt= st.getForObject("http://localhost:8686/Minventory",ArrayList.class );
			return  new ModelAndView("MerchantInventory","inventory" ,ivt);

		} 
		else if(!log.equals("fail")) {
			return new ModelAndView("relogin","user","log");
		}
		return new ModelAndView("relogin","user","log");
		

	}

	@RequestMapping("/set")
	public ModelAndView reest(String username, String newPassword, String confirmPassword) {

		RestTemplate rt = new RestTemplate();
		rt.put("http://localhost:8686/set?username=" + username + "&newPassword=" + newPassword + "&confirmPassword="
				+ confirmPassword, String.class);
		return new ModelAndView("success");
	}

	@RequestMapping("/customers")
	public ModelAndView show() {
		RestTemplate rt = new RestTemplate();
		List<Customer> list = rt.getForObject("http://localhost:8686/customer", ArrayList.class);
		return new ModelAndView("customer", "cust", list);

	}

	@RequestMapping("/merchants")
	public ModelAndView showMerchant() {
		RestTemplate rt = new RestTemplate();
		List<MerchantInfo> list = rt.getForObject("http://localhost:8686/merchant", ArrayList.class);
		return new ModelAndView("merchant", "merch", list);

	}

	@RequestMapping("/inventory")
	public ModelAndView showInventory() {
		RestTemplate rt = new RestTemplate();
		List<Inventory> list = rt.getForObject("http://localhost:8686/inventory", ArrayList.class);
		return new ModelAndView("inventory", "inv", list);

	}

	@RequestMapping("/profile")
	public ModelAndView showAdmin() {
		RestTemplate rt = new RestTemplate();
		List<Admin> list = rt.getForObject("http://localhost:8686/admin", ArrayList.class);
		return new ModelAndView("profile", "adm", list);

	}

}
