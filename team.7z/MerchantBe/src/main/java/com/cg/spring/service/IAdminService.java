package com.cg.spring.service;

import java.util.List;

import com.cg.spring.beans.Admin;
import com.cg.spring.beans.Customer;
import com.cg.spring.beans.MerchantInfo;
import com.cg.spring.beans.MerchantInventory;

public interface IAdminService {

	public List<Customer> showAllCustomers();

	public List<MerchantInfo> showAllMerchant();

	public List<MerchantInventory> showAllInventory();

	public List<Admin> showAdminProfile();
}
