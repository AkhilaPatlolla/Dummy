package com.cg.spring.service;

public interface ILoginService {
	public String check(String username, String password) throws Exception;
	public boolean reset(String username, String newPassword,String confirmPassword) throws Exception;
}
