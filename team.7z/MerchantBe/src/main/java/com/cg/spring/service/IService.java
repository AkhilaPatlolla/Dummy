package com.cg.spring.service;

import java.util.List;
import java.util.Optional;

import com.cg.spring.beans.MerchantInfo;
import com.cg.spring.beans.MerchantOrders;
import com.cg.spring.beans.ProductBean;

public interface IService {

	Optional<MerchantInfo> displayInfo(String email);

	List<MerchantOrders> displayorders(String email);

	List<ProductBean> displayinventory(String email);

	String addproduct(ProductBean product);

	String deleteproduct(int id);

}
